﻿using Microsoft.AspNetCore.$safeprojectname$;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Models
{
    public class ApplicationRole : IdentityRole<int>
    {
        public ICollection<ApplicationUserRole> UserRoles { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
