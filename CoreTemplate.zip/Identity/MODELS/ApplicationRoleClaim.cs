﻿using Microsoft.AspNetCore.$safeprojectname$;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Models
{
    public class ApplicationRoleClaim : IdentityRoleClaim<int>
    {
    }
}
