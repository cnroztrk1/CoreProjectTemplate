﻿using $safeprojectname$.Attributes;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace $safeprojectname$.Collections
{
    [BsonCollection("loginlogs")]
    [BsonIgnoreExtraElements]
    public class LoginLog : MongoBaseDocument
    {
        public string UserEmail { get; set; }
        public DateTime LoginTime { get; set; }
    }
}