﻿using Microsoft.AspNetCore.Builder;
using $safeprojectname$.Middlewares;

namespace $safeprojectname$.Extensions
{
    public static class AppExtensions
    {
        public static void UseErrorHandlingMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ErrorHandlerMiddleware>();
        }
    }
}
