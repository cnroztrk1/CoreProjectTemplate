﻿namespace $safeprojectname$.Interfaces
{
    public interface IAuthenticatedUserService
    {
        string UserEmail { get; }
    }
}
