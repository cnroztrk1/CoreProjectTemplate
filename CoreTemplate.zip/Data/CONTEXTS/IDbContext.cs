﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Contexts
{
    public interface IDbContext
    {
        DbSet<TEntity> Set<TEntity>() where TEntity : class;
    }
}
