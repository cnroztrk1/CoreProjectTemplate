﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Mapping
{
    public interface IMappingConfiguration
    {
        void ApplyConfiguration(ModelBuilder modelBuilder);
    }
}
